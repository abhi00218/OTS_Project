from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register((Student_profile,Subjects,Question,Result))

class SubjectsAdmin(admin.ModelAdmin):
    list_display = ('sub_name', 'image')
    search_fields = ('sub_name',)

