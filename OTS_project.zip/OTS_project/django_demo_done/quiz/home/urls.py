from django.urls import path
from . import views

urlpatterns = [
    path('', views.homePage),
    path('signup/', views.signupPage),
    path('login/', views.loginPage),
    path('subject/', views.subjectPage),
    path('exam/<int:id>/', views.examPage),
    path('result/<int:id>/', views.resultPage),
    path("logout/",views.logoutpage)
]

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)